// Register page placeholder
