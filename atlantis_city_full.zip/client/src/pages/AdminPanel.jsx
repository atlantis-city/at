// Admin panel page placeholder
